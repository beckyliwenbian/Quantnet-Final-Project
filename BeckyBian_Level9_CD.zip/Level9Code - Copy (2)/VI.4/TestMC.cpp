// HardCoded.cpp
//
// C++ code to price an option, essential algorithms.
//
// We take CEV model with a choice of the elaticity parameter
// and the Euler method. We give option price and number of times
// S hits the origin.
//
// (C) Datasim Education BC 2008-2011
//

#include "OptionData.hpp" 
#include "UtilitiesDJD/RNG/NormalGenerator.hpp"
#include "UtilitiesDJD/Geometry/Range.cpp"
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>
#include <cmath>
#include <iostream>
using namespace std;


template <class T> void print(const vector<T>& myList)
{  // A generic print function for vectors

	cout << endl << "Size of vector is " << l.size() << "\n[";

	// We must use a const iterator here, otherwise we get a compiler error.
	vector<T>::const_iterator i;
	for (i = myList.begin(); i != myList.end(); ++i)
	{
		cout << *i << ",";

	}

	cout << "]\n";
}

//for D
//a tuple which outputs sd and se to tell accuracy and volatility of simulation
template <typename Type>
boost::tuple<Type, Type> accuracy(const vector<Type>& price, const Type& r, const Type& T)
{
	//input is a vector of size M, interest free rate and epiry time T
	Type tmp1(0), tmp2(0);
	for (int i = 0; i < price.size(); i++) {
		tmp1 += price[i] * price[i];
		tmp2 += price[i];
	}

	int M = price.size();
	Type sd = sqrt(tmp1 - 1 / M * tmp2 * tmp2) * exp(-2 * r * T) / (M - 1);
	Type se = sd / sqrt(M);

	return boost::make_tuple(sd, se);
}

namespace SDEDefinition
{ // Defines drift + diffusion + data

	OptionData* data;				// The data for the option MC

	double drift(double t, double X)
	{ // Drift term

		return (data->r) * X; // r - D
	}


	double diffusion(double t, double X)
	{ // Diffusion term

		double betaCEV = 1.0;
		return data->sig * pow(X, betaCEV);

	}

	double diffusionDerivative(double t, double X)
	{ // Diffusion term, needed for the Milstein method

		double betaCEV = 1.0;
		return 0.5 * (data->sig) * (betaCEV)*pow(X, 2.0 * betaCEV - 1.0);
	}
} // End of namespace

int main()
{
	//C-a.
	//test by using data from different batches
	cout << "1 factor MC with explicit Euler\n";
	// Store Batch 1 to Batch 2 data in a vector.
	typedef boost::tuple<double, double, double, double, double> batch;
	vector<batch> vecbatch;
	vecbatch.push_back(boost::make_tuple(65.0, 0.25, 0.08, 0.30, 60.0));
	vecbatch.push_back(boost::make_tuple(100.0, 1.00, 0.00, 0.20, 100.0));

	for (int num = 1; num <= vecbatch.size(); ++num) {
		OptionData myOption;
		myOption.K = vecbatch[num - 1].get<0>(); // 100 for batch2
		myOption.T = vecbatch[num - 1].get<1>();  // 1.0 for batch2
		myOption.r = vecbatch[num - 1].get<2>(); // 0.0 for batch2
		myOption.sig = vecbatch[num - 1].get<3>(); // 0.2 for batch2
		myOption.type = -1;	// Put -1, Call +1
		double S_0 = vecbatch[num - 1].get<4>();

		//myOption.K = vecbatch[num-1].get<0>(); // 100 for batch2
		//myOption.T = vecbatch[num - 1].get<1>();  // 1.0 for batch2
		//myOption.r = vecbatch[num - 1].get<2>(); // 0.0 for batch2
		//myOption.sig = vecbatch[num - 1].get<3>(); // 0.2 for batch2
		//myOption.type = -1;	// Put -1, Call +1
		//double S_0 = vecbatch[num - 1].get<4>();

		long N = 100;
		cout << "Number of subintervals in time: ";
		cin >> N;

		// Create the basic SDE (Context class)
		Range<double> range(0.0, myOption.T);
		double VOld = S_0;
		double VNew;

		vector<double> x = range.mesh(N);


		// V2 mediator stuff
		long NSim = 50000;
		cout << "Number of simulations: ";
		cin >> NSim;

		double k = myOption.T / double(N);
		double sqrk = sqrt(k);

		// Normal random number
		double dW;
		// Put option price.
		double price1 = 0.0;
		// Call option price.
		double price2 = 0.0;

		// Vector to store the prices of put and call.
		vector<double> veccall, vecput;

		// NormalGenerator is a base class
		NormalGenerator* myNormal = new BoostNormal();

		using namespace SDEDefinition;
		SDEDefinition::data = &myOption;

		vector<double> res;
		int coun = 0; // Number of times S hits origin

		// A.
		for (long i = 1; i <= NSim; ++i)
		{ // Calculate a path at each iteration

			if ((i / 10000) * 10000 == i)
			{// Give status after each 1000th iteration

				cout << i << endl;
			}

			VOld = S_0;
			for (unsigned long index = 1; index < x.size(); ++index)
			{

				// Create a random number
				dW = myNormal->getNormal();

				// The FDM (in this case explicit Euler)
				VNew = VOld + (k * drift(x[index - 1], VOld))
					+ (sqrk * diffusion(x[index - 1], VOld) * dW);

				VOld = VNew;

				// Spurious values
				if (VNew <= 0.0) coun++;
			}

			double tmp1 = myOption.myPayOffFunction(VNew);
			price1 += (tmp1) / double(NSim); //notice: this option is iniated as a put
			vecput.push_back(tmp1);
			myOption.type = 1; //change this option into a call
			double tmp2 = myOption.myPayOffFunction(VNew);
			price2 += (tmp2) / double(NSim);
			veccall.push_back(tmp2);
			myOption.type = -1; //the option becomes a put again
		}

		// D. Finally, discounting the average price
		price1 *= exp(-myOption.r * myOption.T); //for put
		price2 *= exp(-myOption.r * myOption.T); //for call

		// Cleanup; V2 use scoped pointer
		delete myNormal;

		cout << "Price, after discounting: Call = " << price2 << ",  Put = " << price1 << endl;
		cout << "Number of times origin is hit: " << coun << endl;

		//print out sd and se to tell simulation accuracy and volatility
		boost::tuple<double, double> tuplecall = accuracy<double>(veccall, myOption.r, myOption.T);
		boost::tuple<double, double> tupleput = accuracy<double>(vecput, myOption.r, myOption.T);
		cout << "For this batch " << num << ", Call Option, number of subintervals = " << N << ", number of simulations = " << NSim
			<< ", standard deviation = " << tuplecall.get<0>() << ", standard error = " << tuplecall.get<1>() << endl;
		cout << "For this batch " << num << ", Put Option, number of subintervals = " << N << ", number of simulations = " << NSim
			<< ", standard deviation = " << tupleput.get<0>() << ", standard error = " << tupleput.get<1>() << endl;

	}
	return 0;
}

