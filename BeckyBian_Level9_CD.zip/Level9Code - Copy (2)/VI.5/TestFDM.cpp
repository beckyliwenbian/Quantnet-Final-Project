// TestFDM.cpp
//
// Test program for the exact solutions of European options and print results in Excel.
//
// (C) Datasim Education BV 2005-2011
//
// Gruop F


#include "FDMDirector.h"

#include <iostream>
#include <string>
using namespace std;

#include "UtilitiesDJD/ExcelDriver/ExcelDriverLite.hpp"

namespace BS // Black Scholes
{
	//initialize using batch 1 data
	double sig = 0.3;
	double K = 65.0;
	double T = 0.25;
	double r = 0.08;
	double D = 0.0; // aka q

	double mySigma(double x, double t)
	{

		double sigmaS = sig * sig;

		return 0.5 * sigmaS * x * x;
	}

	double myMu(double x, double t)
	{

		return (r - D) * x;

	}

	double myB(double x, double t)
	{

		return  -r;
	}

	double myF(double x, double t)
	{
		return 0.0;
	}

	double myBCL(double t)
	{
		// Put
		return K * exp(-r * t);
	}

	double myBCR(double t)
	{

		// Put
		return 0.0; // P
	}

	double myIC(double x)
	{ // Payoff

		// Put
		return max(K - x, 0.0);
	}

}

int main()
{
	using namespace ParabolicIBVP;

	// Assignment of functions
	sigma = BS::mySigma;
	mu = BS::myMu;
	b = BS::myB;
	f = BS::myF;
	BCL = BS::myBCL;
	BCR = BS::myBCR;
	IC = BS::myIC;

	//batch 1 -- run directly as the intialized data in BS is from batch 1
	// int J=5*BS::K
	int J1 = static_cast<int>(5 * BS::K);
	int N1 = 5000; // k = O(h^2) !!!!!!!!!

	double Smax1 = 5 * BS::K;			// Magix

	cout << "start FDM\n";
	FDMDirector fdir1(Smax1, BS::T, J1, N1);
	fdir1.doit();
	cout << "Finished\n";
	// Have you Excel installed (ExcelImports.cpp)
	printOneExcel(fdir1.xarr, fdir1.current(), string("Value"));

	//batch 2
	BS::T = 1;
	BS::K = 100;
	BS::sig = 0.2;
	BS::r = 0.00;

	// int J=5*BS::K
	int J2 = static_cast<int>(5 * BS::K);
	int N2 = 5000; // k = O(h^2) !!!!!!!!!

	double Smax2 = 5 * BS::K;			// Magix

	cout << "start FDM\n";
	FDMDirector fdir2(Smax2, BS::T, J2, N2);
	fdir2.doit();
	cout << "Finished\n";
	// Have you Excel installed (ExcelImports.cpp)
	printOneExcel(fdir2.xarr, fdir2.current(), string("Value"));

	//batch 3
	BS::T = 1;
	BS::K = 10;
	BS::sig = 0.5;
	BS::r = 0.12;

	// int J=5*BS::K
	int J3 = static_cast<int>(5 * BS::K);
	int N3 = 5000; // k = O(h^2) !!!!!!!!!

	double Smax3 = 5 * BS::K;			// Magix

	cout << "start FDM\n";
	FDMDirector fdir3(Smax3, BS::T, J3, N3);
	fdir3.doit();
	cout << "Finished\n";
	// Have you Excel installed (ExcelImports.cpp)
	printOneExcel(fdir3.xarr, fdir3.current(), string("Value"));

	//batch 4
	BS::T = 30;
	BS::K = 100;
	BS::sig = 0.3;
	BS::r = 0.08;

	// int J=5*BS::K
	int J4 = static_cast<int>(5 * BS::K);
	int N4 = 5000; // k = O(h^2) !!!!!!!!!

	double Smax4 = 5 * BS::K;			// Magix

	cout << "start FDM\n";
	FDMDirector fdir4(Smax4, BS::T, J4, N4);
	fdir4.doit();
	cout << "Finished\n";
	// Have you Excel installed (ExcelImports.cpp)
	printOneExcel(fdir4.xarr, fdir4.current(), string("Value"));


	return 0;
}

/*#ifndef max
#define max(a, b) (a > b) ? (a) : (b)
#endif

#include "FdmDirector.hpp"
#include "UtilitiesDJD/VectorsAndMatrices/Vector.cpp"
#include "UtilitiesDJD/Geometry/Range.cpp"
#include "UtilitiesDJD/ExceptionClasses/DatasimException.hpp"
#include "FdmDirector.hpp"
#include <cmath>
#include <list>
#include <string>
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

#include "UtilitiesDJD/ExcelDriver/ExcelDriverLite.hpp"

enum OptionType
{
	Put,
	Call
};

namespace BS // Black Scholes
{
	double sig = 0.3;
	double K = 65.0;
	double T = 0.25;
	double r = 0.08;
	double D = 0.0; // aka q
	double Smax = 5.0 * K;
	enum OptionType Type = Call;


	double mySigma (double x, double t)
	{

		double sigmaS = sig*sig;

		return 0.5 * sigmaS * x * x;
	}

	double myMu (double x, double t)
	{
		
		return (r - D) * x;
	
	}

	double myB (double x, double t)
	{	
	
		return  -r;
	}

	double myF (double x, double t)
	{
		return 0.0;
	}

	double myBCL (double t)		
	{
		if (Type == Call)
		{
			return 0.0;
		}
		else
		{
			return K * exp(-r * t);
		}
	}

	double myBCR (double t)
	{
		if (Type == Call)
		{
			return Smax;
		}
		else
		{
			return 0.0;
		}
	}

	double myIC (double x)
	{ // Payoff 
		if (Type == Call)
		{
			return max(x - K, 0.0);
		}
		else
		{
			return max(K - x, 0.0);
		}
	}

}


int main()
{
	// Store Batch 1 to Batch 4 data in a vector.
	typedef boost::tuple<double, double, double, double, double> TupleFive;
	vector<TupleFive> vecBatch;
	vecBatch.push_back(boost::make_tuple(0.25, 65, 0.30, 0.08, 0.0));
	vecBatch.push_back(boost::make_tuple(1.0, 100, 0.2, 0.0, 0.0));
	vecBatch.push_back(boost::make_tuple(1.0, 10, 0.50, 0.12, 0.0));
	vecBatch.push_back(boost::make_tuple(30.0, 100.0, 0.30, 0.08, 0.0));
	// Name of each column.
	stringstream ss;
	string str;
	// The list of option price vectors.
	using namespace ParabolicIBVP;

	// Assignment of functions
	sigma = BS::mySigma;
	mu = BS::myMu;
	b = BS::myB;
	f = BS::myF;
	BCL = BS::myBCL;
	BCR = BS::myBCR;
	IC = BS::myIC;

	//int J = 5.0 * BS::K;
	int J = 50;
	//int N = 100000; // k = O(h^2)
	int N = 5000;
	double Smax = 50;

	for (int i = 0; i < vecBatch.size(); i++)
	{
		cout << "Batch " << i + 1 << ": start FDM;" << endl;
		ss << i + 1;
		ss >> str;
		ss.clear();
		std::list<std::string> labels;
		labels.push_back("Batch " + str + " Call");
		labels.push_back("Batch " + str + " Put");
		std::list<vector<double> > functionResult;

		// Load parameter value of the batch.
		BS::T = vecBatch[i].get<0>();
		BS::K = vecBatch[i].get<1>();
		BS::sig = vecBatch[i].get<2>();
		BS::r = vecBatch[i].get<3>();
		BS::D = vecBatch[i].get<4>();
		//BS::Smax = 5 * BS::K;
		BS::Smax = Smax;
		BS::Type = Call;

		// Calculate call option price.
		FDMDirector fdirCall(BS::Smax, BS::T, J, N);
		fdirCall.doit();
		functionResult.push_back(fdirCall.current());

		// Calculate put option price.
		BS::Type = Put;
		FDMDirector fdirPut(BS::Smax, BS::T, J, N);
		fdirPut.doit();
		functionResult.push_back(fdirPut.current());

		// Print the results in Excel.
		try
		{
			ExcelDriver xl; xl.MakeVisible(true);
			xl.CreateChart(fdirCall.xarr, labels, functionResult,
				string("Graph of Batch " + str), string("Underlying Value"), string("Option Price"));
		}
		catch (DatasimException& e)
		{
			e.print();
		}

		cout << "Batch " << i + 1 << ": finished." << endl;
	}
}*/
