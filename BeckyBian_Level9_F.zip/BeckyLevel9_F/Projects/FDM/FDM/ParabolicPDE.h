//
// Created by becky bian on 2022/7/31.
//

#ifndef GROUPF_PARABOLICPDE_H
#define GROUPF_PARABOLICPDE_H
namespace ParabolicIBVP
{

    // Coefficients of PDE equation
    double (*sigma)(double x, double t); // Diffusion term
    double (*mu)(double x, double t);	 // Convection term
    double (*b)(double x, double t);	 // Free term
    double (*f)(double x, double t);	 // The forcing term term


    // (Dirichlet) boundary conditions
    double (*BCL)(double t);	 // The left-hand boundary condition
    double (*BCR)(double t);	 // The right-hand boundary condition

    // Initial condition
    double (*IC)(double x);		// The condition at time t = 0

}
#endif //GROUPF_PARABOLICPDE_H
