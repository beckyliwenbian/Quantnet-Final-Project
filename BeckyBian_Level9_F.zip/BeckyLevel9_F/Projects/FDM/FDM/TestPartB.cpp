// TestBSPDE1.cpp
//
// Testing 1 factor BS model.
//
// (C) Datasim Education BV 2005-2011
//

#include "FDMDirector.h"
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>
#include <iostream>
#include <string>
using namespace std;

#include "UtilitiesDJD/ExcelDriver/ExcelDriverLite.hpp"

namespace BS // Black Scholes
{
    //initialize using batch 1 data
    double sig = 0.3;
    double K = 65.0;
    double T = 0.25;
    double r = 0.08;
    double D = 0.0; // aka q
    double Smax1 = 5.0 * K;
    string Type = "Call";

    double mySigma(double x, double t)
    {

        double sigmaS = sig * sig;

        return 0.5 * sigmaS * x * x;
    }

    double myMu(double x, double t)
    {

        return (r - D) * x;

    }

    double myB(double x, double t)
    {

        return  -r;
    }

    double myF(double x, double t)
    {
        return 0.0;
    }

    double myBCL(double t)
    {
        if (Type == "Call")
        {
            return 0.0;
        }
        else
        {
            return K * exp(-r * t);
        }
    }

    double myBCR(double t)
    {
        if (Type == "Call")
        {
            return Smax1;
        }
        else
        {
            return 0.0;
        }
    }

    double myIC(double x)
    { // Payoff

        if (Type == "Call")
        {
            return max(x - K, 0.0);
        }
        else
        {
            return max(K - x, 0.0);
        }
    }

}

int main(){
    //create vectors to store all the required info and batch info
    //vector<double> Svector = mesher(10, 50, 1); // Vector of S values.
    //int Svecsize = Svector.size();   //put it in the loop later as we need them for each excel file
    //list<std::string> labels; // Names of each batch
    //list<vector<double> > functionResult; // The list of price values

    // Store Batch 1 to Batch 4 data in a vector.
    typedef boost::tuple<double, double, double, double, double> tuplefive;
    vector<tuplefive> vecbatch;
    vecbatch.push_back(boost::make_tuple(0.25, 65, 0.30, 0.08, 0.0));
    vecbatch.push_back(boost::make_tuple(1.0, 100, 0.2, 0.0, 0.0));
    vecbatch.push_back(boost::make_tuple(1.0, 10, 0.50, 0.12, 0.0));
    vecbatch.push_back(boost::make_tuple(30.0, 100.0, 0.30, 0.08, 0.0));
    // Name of each column.
    stringstream ss;
    string str;
    // The list of option price vectors.
    using namespace ParabolicIBVP;

    // Assignment of functions
    sigma = BS::mySigma;
    mu = BS::myMu;
    b = BS::myB;
    f = BS::myF;
    BCL = BS::myBCL;
    BCR = BS::myBCR;
    IC = BS::myIC;

    // int J=5*BS::K
    int J1 = 50;
    int N1 = 5000; // k = O(h^2) !!!!!!!!!
    double Smax1 = 50;			// Magix

    for (int i = 0; i < vecbatch.size(); i++)
    {
        cout << "Batch " << i + 1 << ": start FDM;" << endl;
        ss << i + 1;
        ss >> str;
        ss.clear();

        //create vectors to store all the labels for this excel
        list<std::string> labels;
        labels.push_back("Batch " + str + " Call");
        labels.push_back("Batch " + str + " Put");
        list<vector<double> > functionResult; //we put it in the loop as we want it for every excel

        // Load parameter value of the batch.
        BS::T = vecbatch[i].get<0>();
        BS::K = vecbatch[i].get<1>();
        BS::sig = vecbatch[i].get<2>();
        BS::r = vecbatch[i].get<3>();
        BS::D = vecbatch[i].get<4>();
        //BS::Smax = 5 * BS::K;
        BS::Smax1 = Smax1;
        BS::Type = "Call";

        // Calculate call option price.
        FDMDirector fdirCall(BS::Smax1, BS::T, J1, N1);
        fdirCall.doit();
        functionResult.push_back(fdirCall.current());

        // Calculate put option price.
        BS::Type = "Put"; //it becomes a put now
        FDMDirector fdirPut(BS::Smax1, BS::T, J1, N1);
        fdirPut.doit();
        functionResult.push_back(fdirPut.current());

        // Print the results in Excel.
        try
        {
            ExcelDriver xl; xl.MakeVisible(true);
            xl.CreateChart(fdirCall.xarr, labels, functionResult,
                string("Graph of Batch " + str), string("Underlying Value"), string("Option Price"));
        }
        catch (DatasimException& e)
        {
            e.print();
        }

        cout << "Batch " << i + 1 << ": finished." << endl;
    }

    

    return 0;
}

