//
// Created by becky bian on 2022/9/9.
//
//include useful header files
#include "AmericanOption.h"
//#include <boost/math/distributions/normal.hpp>
#include <cmath>
#include <iostream>

//using namespace boost::math;
using namespace std;

double AmericanOption::CallPrice() const {
    // Price of call
    // call global functions
    return ::CallPrice(K, sig, r, S, b);
}

double AmericanOption::PutPrice() const {
    // Price of put
    return ::PutPrice(K, sig, r, S, b);
}

/////////////////////////////////////////////////////////////////////////////////////

void AmericanOption::init() {	// Initialise all default values

    //firstly initialize parent class
    Option::init();  // Call Option (this is the default type)

    // Default values
    r = 0.1;
    sig = 0.1;

    K = 100.0;
    S = 110;

    b = 0.02;			// Black and Scholes stock option model (1973)

}

void AmericanOption::copy(const AmericanOption& o2) {
    //copy from parent class first
    Option::copy(o2);

    r = o2.r;
    sig = o2.sig;
    K = o2.K;
    b = o2.b;
    S = o2.S;


}

AmericanOption::AmericanOption() : Option() { // Default constructor which generates a call option
    init();
}


AmericanOption::AmericanOption(const AmericanOption& option2) : Option(option2) { // Copy constructor
    copy(option2);
}

AmericanOption::AmericanOption(const string& optionType) : Option(optionType) {	// Constructor with Option Type
    init();
}

AmericanOption::AmericanOption(const struct AmericanOptionData& optionData) : Option() { // Constructor with option data

    init();
    K = optionData.K;
    sig = optionData.sig;
    r = optionData.r;
    S = optionData.S;
    b = optionData.b;
}

AmericanOption::~AmericanOption() { //Destructor

}


AmericanOption& AmericanOption::operator = (const AmericanOption& option2) { // Assignment operator

    Option::operator = (option2);

    //prevent self-assignment
    if (this == &option2) return *this;

    //copy from input option
    copy(option2);

    return *this;
}

double AmericanOption::PriceWithS(double new_S) const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return ::CallPrice(K, sig, r, new_S, b);
    }
    else {
        return ::PutPrice(K, sig, r, new_S, b);
    }
}

double AmericanOption::PriceWithSig(double new_sig) const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return ::CallPrice(K, new_sig, r, S, b);
    }
    else {
        return ::PutPrice(K, new_sig, r, S, b);
    }
}

double AmericanOption::PriceWithSSig(double new_S, double new_sig) const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return ::CallPrice(K, new_sig, r, new_S, b);
    }
    else {
        return ::PutPrice(K, new_sig, r, new_S, b);
    }
}

//global functions
double CallPrice(double K, double sig, double r, double S, double b) {
    double sig_sq = sig * sig;
    double fac = b / sig_sq - 0.5;
    fac *= fac;
    double y1 = 0.5 - b / sig_sq + sqrt(fac + 2.0 * r / sig_sq);

    if (y1 == 1.0) {
        return S;
    }

    double fac2 = ((y1 - 1.0) * S) / (y1 * K);

    return K * pow(fac2, y1) / (y1 - 1.0);
}

double PutPrice(double K, double sig, double r, double S, double b) {
    double sig_sq = sig * sig;
    double fac = b / sig_sq - 0.5;
    fac *= fac;
    double y2 = 0.5 - b / sig_sq - sqrt(fac + 2.0 * r / sig_sq);

    if (y2 == 0.0) {
        return S;
    }

    double fac2 = ((y2 - 1.0) * S) / (y2 * K);

    return K * pow(fac2, y2) / (1.0 - y2);
}


