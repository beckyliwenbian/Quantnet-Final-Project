#include <vector>
//include header files
#include "Option.h"
#include "AmericanOption.h"
#include <iostream>
using namespace std;

vector<double> mesher(double min, double max, double h) {
    int nelements = (max - min) / h + 1;

    vector<double> xarr(nelements);
    xarr[0] = min;
    xarr[xarr.size() - 1] = max;

    for (int n = 1; n < xarr.size() - 1; ++n) {
        xarr[n] = xarr[n - 1] + h;
    }

    return xarr;
}

int main() {
    // All options are European
    //a&b.
    //Batch 1
    double K1 = 100;
    double sig1 = 0.10;
    double r1 = 0.1;
    double S1 = 110;
    double b1 = 0.02;
    //use global function to compute for price of batch 1 as a trial
    double C1 = CallPrice(K1, sig1, r1, S1, b1);
    double P1 = PutPrice(K1, sig1, r1, S1, b1);
    cout << "Call Option by global function: " << C1 << endl;
    cout << "Put Option by global function: " << P1 << endl;
    //use an instance of AmericanOption class to compute for price as a trial
    AmericanOption option1;
    option1.K = K1;
    option1.sig = sig1;
    option1.r = r1;
    option1.S = S1;
    option1.b = b1;
    cout << "Call Option by option instance: " << option1.Price() << endl;
    option1.toggle(); //a put now
    cout << "Put Option by option instance: " << option1.Price() << endl;
    option1.toggle(); //a call now

    //c.
    vector<double> Svector = mesher(10, 50, 1); // Vector of S values.
    int Svecsize = Svector.size();
    // a vector showing all the computed call prices with different S values
    vector<double> call1(Svecsize);
    // a vector showing all the computed put prices with different S values
    vector<double> put1(Svecsize);
    cout << "compute the price for a range of underlying prices" << endl;
    for (int i = 0; i < Svecsize; ++i) {
        call1[i] = option1.PriceWithS(Svector[i]);
        option1.toggle(); //now, it's put again
        put1[i] = option1.PriceWithS(Svector[i]);
        option1.toggle(); //now, it's call again

    }

    //print out the elements in the stored vector
    for (int i = 0; i < call1.size(); ++i) {
        cout << "Current Price: " << Svector[i] << " Call Price: " << call1[i] << " Put Price: " << put1[i] << endl;
    }


    //d.
    // create an input matrix containing i) volatility, ii) asset value S
    vector<double> sigvector = mesher(0.1, 0.8, 0.1); // Vector of sigs
    int sigvecsize = sigvector.size();
    //cout<<Tvecsize<<endl;
    vector<double> svector = mesher(10, 80, 10); // Vector of S values.
    int svecsize = svector.size();
    //cout<<sigvecsize<<endl;
    vector<vector<double>> matrix(sigvecsize);
    for (int i = 0; i < sigvecsize; ++i) {
        int col = 2;
        matrix[i] = vector<double>(2);
        for (int j = 0; j < 2; j++) {
            if (j == 0) {
                matrix[i][j] = sigvector[i];

            }
            else {
                matrix[i][j] = svector[i];

            }
        }
    }

    // compute prices for batch 1 for a range of sig
    vector<double> call1_sig(sigvecsize);
    vector<double> put1_sig(sigvecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "compute its price for a range of sigs" << endl;
    for (int i = 0; i < sigvecsize; ++i) {
        call1_sig[i] = option1.PriceWithSig(matrix[i][0]);
        option1.toggle(); //now, it's put again
        put1_sig[i] = option1.PriceWithSig(matrix[i][0]);
        option1.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call1_sig.size(); ++i) {
        cout << "Volatility: " << matrix[i][0] << " Call Price: " << call1_sig[i] << " Put Price: " << put1_sig[i] << endl;

    }

    // compute prices for batch 1 for a range of new S
    vector<double> call1_s(svecsize);
    vector<double> put1_s(svecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "compute its price for a range of new prices" << endl;
    for (int i = 0; i < svecsize; ++i) {
        call1_s[i] = option1.PriceWithS(matrix[i][1]);
        option1.toggle(); //now, it's put again
        put1_s[i] = option1.PriceWithS(matrix[i][1]);
        option1.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call1_s.size(); ++i) {
        cout << "New Price: " << matrix[i][1] << " Call Price: " << call1_s[i] << " Put Price: " << put1_s[i] << endl;

    }

    // a matrix containing both call and put prices based on different pairs of S and sigs values in each row of input matrix
    vector<vector<double>> callmatrix1(sigvecsize);
    //cout << "New period\t Volatility\t Call prices\t Put prices " << endl;
    cout << "compute its price for a range of pairs of S and volatilities" << endl;
    for (int i = 0; i < sigvecsize; ++i) {
        //compute call price at this T and sig pair level
        double price1 = option1.PriceWithSSig(matrix[i][1], matrix[i][0]);
        option1.toggle(); //this is now put again
        //compute put price at this T and sig pair level
        double price2 = option1.PriceWithSSig(matrix[i][1], matrix[i][0]);
        option1.toggle(); //this is now call again
        callmatrix1[i] = { price1,price2 };
        cout << "New price: " << matrix[i][1] << " Volatility: " << matrix[i][0] << " Call price: " << callmatrix1[i][0] << " Put price: " << callmatrix1[i][1] << endl;

    }

    /*for (int i = 0; i < sigvecsize; ++i) {
    // Notice: if you want to compute it using different combinations of S and sig not folowing the row, a nested loop can be applied here as the second loop is shown below and for batch2,3,4, it should be similar
    for (int j = 0; j < svecsize; j++) {
       //compute call price at this T and sig pair level
        double price1 = option1.PriceWithSSig(matrix[j][1], matrix[i][0]);
        option1.toggle(); //this is now put again
        //compute put price at this T and sig pair level
        double price2 = option1.PriceWithSSig(matrix[j][1], matrix[i][0]);
        option1.toggle(); //this is now call again
        cout << "New price: " << matrix[j][1] << " Volatility: " << matrix[i][0] << " Call price: " << callmatrix1[i][0] << " Put price: " << callmatrix1[i][1] << endl;
    }
 }*/
    return 0;
}
