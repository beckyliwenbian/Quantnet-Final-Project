#pragma once
#ifndef B_AMERICANOPTION_H
#define B_AMERICANOPTION_H
#include <string>
//include header files
#include "Option.h"
using namespace std;

//derived class from Option
class AmericanOption : public Option {

private:

    void init();	// Initialise all default values
    void copy(const AmericanOption& o2);

    double CallPrice() const; // Price of call
    double PutPrice() const;  // Price of put


    // Gaussian functions
    //double n(double x) const;
    //double N(double x) const;

public:

    // Member data public for convenience; anyway, the format will
    // not change for a plain option.

    double r;		// Interest rate
    double sig;		// Volatility
    double K;		// Strike price
    double b;		// Cost of carry
    double S; //asset price current

    //string optType;	// Option name (call, put)
    //string unam;	// Name of underlying asset


public:	// Public functions
    AmericanOption();							// Default call option
    //	Overloaded constructor
    //EuropeanOption(double K_c, double T_c, double r_c, double sig_c, double b_c, double S_c, string str);
    // Overloaded constructor to create  OptionData sturct instance.
    //EuropeanOption(double K_c, double T_c, double r_c, double sig_c, double b_c, double S_c);

    AmericanOption(const AmericanOption& option2);	// Copy constructor
    AmericanOption(const string& optionType);	// Constructor with option type
    AmericanOption(const struct AmericanOptionData& optionData); // Constructor with option data
    virtual ~AmericanOption(); //destructor

    AmericanOption& operator = (const AmericanOption& option2); //assignment operator

    // Functions that calculate option price and sensitivities
    //double CallToPut(double c_price) const; // Use put-call parity to calculate put price
    //double PutToCall(double p_price) const; // Use put-call parity to calculate call price
    double PriceWithS(double new_S) const; // Use underlying price as argument
    double PriceWithSig(double new_sig) const; // Use volatility as argument
    double PriceWithSSig(double new_S, double new_sig) const; // Use volatility as argument
    //double DeltaDiff(double S, double h) const; // Use divided differences to calculate Delta
    //double GammaDiff(double S, double h) const; // Use divided differences to calculate Gamma
    // functions to calculate delta and gamme using divided difference

    // Functions of put_call_parity
    //double CallToPut(double c_price, double asset_price) const; // Use put-call parity to calculate put price
    //double PutToCall(double p_price, double asset_price) const; // Use put-call parity to calculate call price

    // Modifier functions
    //void toggle();		// Change option type (C/P, P/C); it's in parent class
};

struct AmericanOptionData {
    double r;		// Interest rate
    double sig;		// Volatility
    double K;		// Strike price
    double b;		// Cost of carry
    double S; //asset price current
};

// Global Functions
// used to work for all types of options globally
//vector<double> GenerateMeshArray(double min, double max, double h);
double CallPrice(double K, double sig, double r, double S, double b);
double PutPrice(double K, double sig, double r, double S, double b);
//double CallDelta(double K, double sig, double r, double S, double b);
//double PutDelta(double K, double sig, double r, double S, double b);
//double CallGamma(double K, double sig, double r, double S, double b);
//double PutGamma(double K, double sig, double r, double S, double b);
//double CallVega(double K, double sig, double r, double S, double b);
//double PutVega(double K, double sig, double r, double S, double b);
//double CallTheta(double K, double sig, double r, double S, double b);
//double PutTheta(double K, double sig, double r, double S, double b);
#endif //B_AMERICANOPTION_H
