//
// Created by becky bian on 2022/9/9.
//
#include <vector>
//include header files
#include "Option.h"
#include "EuropeanOption.h"
#include <iostream>
using namespace std;

/* Cost of carry factor b must be included in formulae depending on the
   derivative type. These are used in the generalised Black-Scholes formula.
   If r is the risk-free interest and q is the continuous dividend yield then
   the cost-of-carry b per derivative type is:

    a) Black-Scholes (1973) stock option model: b = r
    b) b = r - q Merton (1973) stock option model with continuous dividend yield
    c) b = 0 Black (1976) futures option model
    d) b = r - rf Garman and Kohlhagen (1983) currency option model, where rf is the
       'foreign' interest rate
*/

vector<double> mesher(double min, double max, double h) {
    int nelements = (max - min) / h + 1;

    vector<double> xarr(nelements);
    xarr[0] = min;
    xarr[xarr.size() - 1] = max;

    for (int n = 1; n < xarr.size() - 1; ++n) {
        xarr[n] = xarr[n - 1] + h;
    }

    return xarr;
}

int main() {
    // All options are European
    //1a.
    //Batch 1
    double T1 = 0.25;
    double K1 = 65;
    double sig1 = 0.30;
    double r1 = 0.08;
    double S1 = 60;
    double b1 = r1;
    //use global function to compute for price of batch 1 as a trial
    double C1 = CallPrice(T1, K1, sig1, r1, S1, b1);
    double P1 = PutPrice(T1, K1, sig1, r1, S1, b1);
    cout << "Call Option on batch 1: " << C1 << endl;
    cout << "Put Option on batch 1: " << P1 << endl;
    //use an instance of EuropeanOption class to compute for price as a trial
    EuropeanOption option1;
    option1.T = T1;
    option1.K = K1;
    option1.sig = sig1;
    option1.r = r1;
    option1.S = S1;
    option1.b = b1;
    cout << "Call Option on batch 1: " << option1.Price() << endl;
    option1.toggle(); //a put now
    cout << "Put Option on batch 1: " << option1.Price() << endl;

    //Batch 2
    double T2 = 1.0;
    double K2 = 100;
    double sig2 = 0.2;
    double r2 = 0.0;
    double S2 = 100;
    double b2 = r2;
    //use an instance of EuropeanOption class to compute for price as a trial
    EuropeanOption option2;
    option2.T = T2;
    option2.K = K2;
    option2.sig = sig2;
    option2.r = r2;
    option2.S = S2;
    option2.b = b2;
    double C2 = option2.Price();
    option2.toggle(); //a put now
    double P2 = option2.Price();
    cout << "Call Option on batch 2: " << C2 << endl;
    cout << "Put Option on batch 2: " << P2 << endl;

    //Batch 3
    double T3 = 1.0;
    double K3 = 10;
    double sig3 = 0.50;
    double r3 = 0.12;
    double S3 = 5;
    double b3 = r3;
    //use an instance of EuropeanOption class to compute for price as a trial
    EuropeanOption option3;
    option3.T = T3;
    option3.K = K3;
    option3.sig = sig3;
    option3.r = r3;
    option3.S = S3;
    option3.b = b3;
    double C3 = option3.Price();
    option3.toggle(); //a put now
    double P3 = option3.Price();
    cout << "Call Option on batch 3: " << C3 << endl;
    cout << "Put Option on batch 3: " << P3 << endl;

    //Batch 4
    double T4 = 30.0;
    double K4 = 100;
    double sig4 = 0.30;
    double r4 = 0.08;
    double S4 = 100;
    double b4 = r4;
    //use an instance of EuropeanOption class to compute for price as a trial
    EuropeanOption option4;
    option4.T = T4;
    option4.K = K4;
    option4.sig = sig4;
    option4.r = r4;
    option4.S = S4;
    option4.b = b4;
    double C4 = option4.Price();
    option4.toggle();  //a put now
    double P4 = option4.Price();
    cout << "Call Option on batch 4: " << C4 << endl;
    cout << "Put Option on batch 4: " << P4 << endl;

    //1b.
    //Batch 1
    cout << "Using put-call parity to calculate prices:" << endl;
    //as we have already toggled it, hence, it's currently a put
    double C1_parity = option1.PutToCall(option1.Price());
    cout << "For Batch 1, call price is " << C1_parity << endl;
    option1.toggle(); //now, it's call again
    double P1_parity = option1.CallToPut(option1.Price());
    cout << "For Batch 1, put price is " << P1_parity << endl;

    //Batch 2
    //as we have already toggled it, hence, it's currently a put
    double C2_parity = option2.PutToCall(option2.Price());
    cout << "For Batch 2, call price is " << C2_parity << endl;
    option2.toggle(); //now, it's call again
    double P2_parity = option2.CallToPut(option2.Price());
    cout << "For Batch 2, put price is " << P2_parity << endl;

    //Batch 3
    //as we have already toggled it, hence, it's currently a put
    double C3_parity = option3.PutToCall(option3.Price());
    cout << "For Batch 3, call price is " << C3_parity << endl;
    option3.toggle(); //now, it's call again
    double P3_parity = option3.CallToPut(option3.Price());
    cout << "For Batch 3, put price is " << P3_parity << endl;

    //Batch 4
    //as we have already toggled it, hence, it's currently a put
    double C4_parity = option4.PutToCall(option4.Price());
    cout << "For Batch 4, call price is " << C4_parity << endl;
    option4.toggle(); //now, it's call again
    double P4_parity = option4.CallToPut(option4.Price());
    cout << "For Batch 4, put price is " << P4_parity << endl;

    //1c.
    //Batch 1
    vector<double> Svector = mesher(10, 50, 1); // Vector of S values.
    int Svecsize = Svector.size();
    // a vector showing all the call prices of batch 1 with different S values
    vector<double> call1(Svecsize);
    // a vector showing all the put prices of batch 1 with different S values
    vector<double> put1(Svecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "Batch 1: compute for a range of underlying prices" << endl;
    for (int i = 0; i < Svecsize; ++i) {
        /*EuropeanOption option_1;
        option_1.T = T1;
        option_1.K = K1;
        option_1.sig = sig1;
        option_1.r = r1;
        option_1.S = Svector[i];
        option_1.b = b1;*/
        call1[i] = option1.PriceWithS(Svector[i]);
        option1.toggle(); //now, it's put again
        put1[i] = option1.PriceWithS(Svector[i]);
        option1.toggle(); //now, it's call again

    }

    //print out the elements in the stored vector
    for (int i = 0; i < call1.size(); ++i) {
        cout << "Current Price: " << Svector[i] << " Call Price: " << call1[i] << " Put Price: " << put1[i] << endl;
    }

    // Batch2
    // a vector showing all the call prices of batch 2 with different S values
    vector<double> call2(Svecsize);
    // a vector showing all the put prices of batch 2 with different S values
    vector<double> put2(Svecsize);
    //cout<<"Current price\t Call Prices\t Put Prices"<<endl;
    cout << "Batch 2: compute its price for a range of underlying prices" << endl;
    for (int i = 0; i < Svecsize; ++i) {
        call2[i] = option2.PriceWithS(Svector[i]);
        option2.toggle(); //now, it's put again
        put2[i] = option2.PriceWithS(Svector[i]);
        option2.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call2.size(); ++i) {
        cout << "Current Price: " << Svector[i] << " Call Price: " << call2[i] << " Put Price: " << put2[i] << endl;
    }

    //Batch 3
    // a vector showing all the call prices of batch 3 with different S values
    vector<double> call3(Svecsize);
    // a vector showing all the put prices of batch 3 with different S values
    vector<double> put3(Svecsize);
    //cout<<"Current price\t Call Prices\t Put Prices"<<endl;
    cout << "Batch 3: compute its price for a range of underlying prices " << endl;
    for (int i = 0; i < Svecsize; ++i) {
        call3[i] = option3.PriceWithS(Svector[i]);
        option3.toggle(); //now, it's put again
        put3[i] = option3.PriceWithS(Svector[i]);
        option3.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call3.size(); ++i) {
        cout << "Current Price: " << Svector[i] << " Call Price: " << call3[i] << " Put Price: " << put3[i] << endl;
    }

    //Batch 4
   // a vector showing all the call prices of batch 4 with different S values
    vector<double> call4(Svecsize);
    // a vector showing all the put prices of batch 4 with different S values
    vector<double> put4(Svecsize);
    //cout<<"Current price\t Call Prices\t Put Prices"<<endl;
    cout << "Batch 4: compute its price for a range of underlying prices" << endl;
    for (int i = 0; i < Svecsize; ++i) {
        call4[i] = option4.PriceWithS(Svector[i]);
        option4.toggle(); //now, it's put again
        put4[i] = option4.PriceWithS(Svector[i]);
        option4.toggle(); //now, it's call again
    }
    //print out the elements in the stored vector
    for (int i = 0; i < call4.size(); ++i) {
        cout << "Current Price: " << Svector[i] << " Call Price: " << call4[i] << " Put Price: " << put4[i] << endl;
    }


    //1.d
    // create an input matrix containing i) expiry time, ii) volatility
    vector<double> Tvector = mesher(0.1, 1, 0.01); // Vector of T values.
    int Tvecsize = Tvector.size();
    //cout<<Tvecsize<<endl;
    vector<double> sigvector = mesher(0.1, 1, 0.01); // Vector of sig values.
    int sigvecsize = sigvector.size();
    //cout<<sigvecsize<<endl;
    vector<vector<double>> matrix(Tvecsize);
    for (int i = 0; i < Tvecsize; ++i) {
        int col = 2;
        matrix[i] = vector<double>(2);
        for (int j = 0; j < 2; j++) {
            if (j == 0) {
                matrix[i][j] = Tvector[i];

            }
            else {
                matrix[i][j] = sigvector[i];

            }
        }
    }



    //Batch 1 as a trial, other batches work the same
    // compute prices for batch 1 for a range of expiry time
    vector<double> call1_t(Tvecsize);
    vector<double> put1_t(Tvecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "Batch 1: compute its price for a range of expiry times" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        call1_t[i] = option1.PriceWithT(matrix[i][0]);
        option1.toggle(); //now, it's put again
        put1_t[i] = option1.PriceWithT(matrix[i][0]);
        option1.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call1_t.size(); ++i) {
        cout << "New Period: " << matrix[i][0] << " Call Price: " << call1_t[i] << " Put Price: " << put1_t[i] << endl;

    }

    // compute prices for batch 1 for a range of volatilities
    vector<double> call1_sig(Tvecsize);
    vector<double> put1_sig(Tvecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "Batch 1: compute its price for a range of volatilities" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        call1_sig[i] = option1.PriceWithSig(matrix[i][1]);
        option1.toggle(); //now, it's put again
        put1_sig[i] = option1.PriceWithSig(matrix[i][1]);
        option1.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call1_sig.size(); ++i) {
        cout << "Volatility: " << matrix[i][1] << " Call Price: " << call1_sig[i] << " Put Price: " << put1_sig[i] << endl;

    }


    // a matrix containing both call and put prices based on different pairs of T and sigs values in each row of input matrix
    vector<vector<double>> callmatrix1(Tvecsize);
    //cout << "New period\t Volatility\t Call prices\t Put prices " << endl;
    cout << "Batch 1: compute its price for a range of pairs of T and volatilities" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        //compute call price at this T and sig pair level
        double price1 = option1.PriceWithTsig(matrix[i][0], matrix[i][1]);
        option1.toggle(); //this is now put again
        //compute put price at this T and sig pair level
        double price2 = option1.PriceWithTsig(matrix[i][0], matrix[i][1]);
        option1.toggle(); //this is now call again
        callmatrix1[i] = { price1,price2 };
        cout << "New Period: " << matrix[i][0] << " Volatility: " << matrix[i][1] << " Call price: " << callmatrix1[i][0] << " Put price: " << callmatrix1[i][1] << endl;

    }

    /*for (int i = 0; i < Tvecsize; ++i) {
        // Notice: if you want to compute it using different combinations of T and sig not folowing the row, a nested loop can be applied here as the second loop is shown below and for batch2,3,4, it should be similar
        for (int j = 0; j < sigvecsize; j++) {
           //compute call price at this T and sig pair level
            double price11 = option1.PriceWithTsig(matrix[i][0], matrix[j][1]);
            option1.toggle(); //this is now put again
            //compute put price at this T and sig pair level
            double price22 = option1.PriceWithTsig(matrix[i][0], matrix[j][1]);
            option1.toggle(); //this is now call again
            cout << "New Period: "<<matrix[i][0] << " Volatility: " << matrix[j][1] << " Call price: " << price11 << " Put price: " << price22 << endl;
        }
     }*/
     // a matrix output

     //let's try to print out the matrix
     /*cout<<"call prices\t put prices "<<endl;
     for (int i = 0; i < Tvecsize; ++i){
         cout<<callmatrix1[i][0]<<"\t"<<callmatrix1[i][1]<<endl;
     }*/
     /*for (int i = 0; i < Tvecsize; ++i){
         cout<<"put prices: "<<endl;
         cout<<callmatrix1[i][1]<<endl;}*/

         //Batch 2
         // compute prices for batch 2 for a range of expiry time
    vector<double> call2_t(Tvecsize);
    vector<double> put2_t(Tvecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "Batch 2: compute its price for a range of expiry times" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        call2_t[i] = option2.PriceWithT(matrix[i][0]);
        option2.toggle(); //now, it's put again
        put2_t[i] = option2.PriceWithT(matrix[i][0]);
        option2.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call2_t.size(); ++i) {

        cout << "New Period: " << matrix[i][0] << " Call Price: " << call2_t[i] << " Put Price: " << put2_t[i] << endl;

    }

    // compute prices for batch 2 for a range of volatilities
    vector<double> call2_sig(Tvecsize);
    vector<double> put2_sig(Tvecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "Batch 2: compute its price for a range of volatilities" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        call2_sig[i] = option2.PriceWithSig(matrix[i][1]);
        option2.toggle(); //now, it's put again
        put2_sig[i] = option2.PriceWithSig(matrix[i][1]);
        option2.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call2_sig.size(); ++i) {

        cout << "Volatility: " << matrix[i][1] << " Call Price: " << call2_sig[i] << " Put Price: " << put2_sig[i] << endl;

    }

    // a vector showing all the call prices of batch 2 with different T and sig values
    vector<vector<double>> callmatrix2(Tvecsize);
    //cout<<"New period\t Volatility\t Call prices\t Put prices "<<endl;
    cout << "Batch 2: compute its price for a range of pairs of T and volatilities" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        //compute call price at this T and sig pair level
        double price1_2 = option2.PriceWithTsig(matrix[i][0], matrix[i][1]);
        option2.toggle(); //this is now put again
        //compute put price at this T and sig pair level
        double price2_2 = option2.PriceWithTsig(matrix[i][0], matrix[i][1]);
        option2.toggle(); //this is now call again
        callmatrix2[i] = { price1_2,price2_2 };
        cout << "New Period: " << matrix[i][0] << " Volatility: " << matrix[i][1] << " Call price: " << callmatrix2[i][0] << " Put price: " << callmatrix2[i][1] << endl;
    }


    //Batch 3
    // compute prices for batch 3 for a range of expiry time
    vector<double> call3_t(Tvecsize);
    vector<double> put3_t(Tvecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "Batch 3: compute its price for a range of expiry times" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        call3_t[i] = option3.PriceWithT(matrix[i][0]);
        option3.toggle(); //now, it's put again
        put3_t[i] = option3.PriceWithT(matrix[i][0]);
        option3.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call3_t.size(); ++i) {

        cout << "New Period: " << matrix[i][0] << " Call Price: " << call3_t[i] << " Put Price: " << put3_t[i] << endl;

    }

    // compute prices for batch 3 for a range of volatilities
    // a vector showing all the call prices of batch 1 with different S values
    vector<double> call3_sig(Tvecsize);
    // a vector showing all the put prices of batch 1 with different S values
    vector<double> put3_sig(Tvecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "Batch 3: compute its price for a range of volatilities" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        call3_sig[i] = option3.PriceWithSig(matrix[i][1]);
        option3.toggle(); //now, it's put again
        put3_sig[i] = option3.PriceWithSig(matrix[i][1]);
        option3.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call3_sig.size(); ++i) {

        cout << "Volatility: " << matrix[i][1] << " Call Price: " << call3_sig[i] << " Put Price: " << put3_sig[i] << endl;

    }
    vector<vector<double>> callmatrix3(Tvecsize);
    //cout << "New period\t Volatility\t Call prices\t Put prices " << endl;
    cout << "Batch 3: compute its price for a range of pairs of T and volatilities" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        //compute call price at this T and sig pair level
        double price1_3 = option3.PriceWithTsig(matrix[i][0], matrix[i][1]);
        option3.toggle(); //this is now put again
        //compute put price at this T and sig pair level
        double price2_3 = option3.PriceWithTsig(matrix[i][0], matrix[i][1]);
        option3.toggle(); //this is now put again
        callmatrix3[i] = { price1_3,price2_3 };
        cout << "New Period: " << matrix[i][0] << " Volatility: " << matrix[i][1] << " Call price: " << callmatrix3[i][0] << " Put price: " << callmatrix3[i][1] << endl;
    }

    //Batch 4
    // compute prices for batch 4 for a range of expiry time
    vector<double> call4_t(Tvecsize);
    vector<double> put4_t(Tvecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "Batch 4: compute its price for a range of expiry times" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        call4_t[i] = option4.PriceWithT(matrix[i][0]);
        option4.toggle(); //now, it's put again
        put4_t[i] = option4.PriceWithT(matrix[i][0]);
        option4.toggle(); //now, it's call again

    }

    //print out the elements in the stored vector
    for (int i = 0; i < call4_t.size(); ++i) {

        cout << "New Period: " << matrix[i][0] << " Call Price: " << call4_t[i] << " Put Price: " << put4_t[i] << endl;

    }

    // compute prices for batch 4 for a range of volatilities
    vector<double> call4_sig(Tvecsize);
    vector<double> put4_sig(Tvecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "Batch 4: compute its price for a range of volatilities" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        call4_sig[i] = option4.PriceWithSig(matrix[i][1]);
        option4.toggle(); //now, it's put again
        put4_sig[i] = option4.PriceWithSig(matrix[i][1]);
        option4.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call4_sig.size(); ++i) {

        cout << "Volatility: " << matrix[i][1] << " Call Price: " << call4_sig[i] << " Put Price: " << put4_sig[i] << endl;

    }

    vector<vector<double>> callmatrix4(Tvecsize);
    //cout << "New period\t Volatility\t Call prices\t Put prices " << endl;
    cout << "Batch 4: compute its price for a range of pairs of T and volatilities" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        //compute call price at this T and sig pair level
        double price1_4 = option4.PriceWithTsig(matrix[i][0], matrix[i][1]);
        option4.toggle(); //this is now put again
        //compute put price at this T and sig pair level
        double price2_4 = option4.PriceWithTsig(matrix[i][0], matrix[i][1]);
        option4.toggle(); //this is now put again
        callmatrix4[i] = { price1_4,price2_4 };
        cout << "New Period: " << matrix[i][0] << " Volatility: " << matrix[i][1] << " Call price: " << callmatrix4[i][0] << " Put price: " << callmatrix4[i][1] << endl;
    }



    //2.a
    double K = 100;
    double S = 105;
    double T = 0.5;
    double r = 0.1;
    double b = 0;
    double sig = 0.36;
    //use global function to compute for price of batch 1 as a trial
    cout << "Global function: " << endl;
    cout << "Call Delta: " << CallDelta(T, K, sig, r, S, b) << endl;
    cout << "Put Delta: " << PutDelta(T, K, sig, r, S, b) << endl;
    cout << "Call Gamma: " << CallGamma(T, K, sig, r, S, b) << endl;
    cout << "Put Gamma: " << PutGamma(T, K, sig, r, S, b) << endl;

    //use an instance of EuropeanOption class to compute for price as a trial
    EuropeanOption option1__;  //a call option
    option1__.T = T;
    option1__.K = K;
    option1__.sig = sig;
    option1__.r = r;
    option1__.S = S;
    option1__.b = b;
    cout << "Use European Class to Compute: " << endl;
    cout << "Call Delta: " << option1__.Delta() << endl;
    cout << "Call Gamma: " << option1__.Gamma() << endl;
    option1__.toggle(); //a put option now
    cout << "Put Delta: " << option1__.Delta() << endl;
    cout << "Put Gamma: " << option1__.Gamma() << endl;
    option1__.toggle(); //a call option now


    //2.b
    // a vector showing all the call prices of batch 1 with different S values
    vector<double> calldeltas(Svecsize); //Notice:Svector defined in 1c
    // a vector showing all the put prices of batch 1 with different S values
    vector<double> putdeltas(Svecsize);
    //cout << "Current price\t Delta\t Put Delta" << endl;
    cout << "Compute delta with a range of underlying prices: " << endl;
    for (int i = 0; i < Svecsize; ++i) {
        option1__.S = Svector[i];
        calldeltas[i] = option1__.Delta();
        option1__.toggle(); //a put option now
        putdeltas[i] = option1__.Delta();
        option1__.toggle(); //a call option now
        //cout << Svector[i] << "\t" << calldeltas[i] << "\t" << putdeltas[i] << endl;

    }
    //print out the elements in the stored vector
    for (int i = 0; i < calldeltas.size(); ++i) {

        cout << "Current Price: " << Svector[i] << " Call Delta: " << calldeltas[i] << " Put Delta: " << putdeltas[i] << endl;
        //cout << Svector[i] << "\t" << calldeltas[i] << "\t" << putdeltas[i] << endl;

    }

    /*for (int i = 0; i < Svecsize; ++i){
        cout<<"call delta: "<<endl;
        cout<<calldeltas[i]<<endl;
    }
    for (int i = 0; i < Svecsize; ++i){
        cout<<"put delta: "<<endl;
        cout<<putdeltas[i]<<endl;
    }*/

    //2.c
    // compute delta for a range of expiry time
    vector<double> call_dt(Tvecsize);
    vector<double> put_dt(Tvecsize);
    cout << "compute its delta for a range of expiry times" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        option1__.T = matrix[i][0];
        call_dt[i] = option1__.Delta();
        option1__.toggle(); //now, it's put again
        put_dt[i] = option1__.Delta();
        option1__.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call_dt.size(); ++i) {

        cout << "New Period: " << matrix[i][0] << " Call Delta: " << call_dt[i] << " Put Delta: " << put_dt[i] << endl;

    }

    // compute delta for a range of volatilities
    vector<double> call_dsig(Tvecsize);
    vector<double> put_dsig(Tvecsize);
    //cout << "Current price\t Call Prices\t Put Prices" << endl;
    cout << "compute its delta for a range of volatilities" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        option1__.sig = matrix[i][1];
        call_dsig[i] = option1__.Delta();
        option1__.toggle(); //now, it's put again
        put_dsig[i] = option1__.Delta();
        option1__.toggle(); //now, it's call again

    }
    //print out the elements in the stored vector
    for (int i = 0; i < call_dsig.size(); ++i) {

        cout << "Volatility: " << matrix[i][1] << " Call Delta: " << call_dsig[i] << " Put Delta: " << put_dsig[i] << endl;

    }

    // a matrix showing all the call and put deltas of batch 5 in each row with different T and sig values
    vector<vector<double>> deltamatrix1(Tvecsize);
    //cout << "New period\t Volatility\t Call delta\t Put delta " << endl;
    cout << "compute its delta for a range of pairs of T and sig" << endl;
    for (int i = 0; i < Tvecsize; ++i) {
        //use the input matrix to compute for differentt deltas
        option1__.T = matrix[i][0];
        option1__.sig = matrix[i][1];
        double calldel1 = option1__.Delta();  //compute the call delta here
        option1__.toggle(); //a put option now
        double putdel1 = option1__.Delta();    //compute the put delta here
        option1__.toggle(); //a call option now
        deltamatrix1[i] = { calldel1,putdel1 };  //finally we should output a matrix contiang two columns of prices corresponding to different pair of T and sig values
        //cout << matrix[i][0] << "\t" << matrix[i][1] << "\t" << deltamatrix1[i][0] << "\t" << deltamatrix1[i][1] << endl;
        cout << "New Period: " << matrix[i][0] << " Volatility: " << matrix[i][1] << " Call Delta: " << deltamatrix1[i][0] << " Put Delta: " << deltamatrix1[i][1] << endl;
    }

    //let's try to print out the matrix
    /*cout<<"call deltas\t put deltas "<<endl;
    for (int i = 0; i < Tvecsize; ++i){
        cout<<deltamatrix1[i][0]<<"\t"<<deltamatrix1[i][1]<<endl;
    }*/

    /*for (int i = 0; i < Tvecsize; ++i){
        cout<<"call delta: "<<endl;
        cout<<deltamatrix1[i][0]<<endl;
    }
    for (int i = 0; i < Tvecsize; ++i){
        cout<<"put delta: "<<endl;
        cout<<deltamatrix1[i][0]<<endl;}
        */
        /*
        // a vector showing all the call prices of batch 2 with different T and sig values
        vector<double> calldelta_5(Tvecsize);
        // a vector showing all the put prices of batch 2 with different T and sig values
        vector<double> putdelta_5(Tvecsize);
        for (int i = 0; i < Tvecsize; ++i){
            EuropeanOption Batch_5_1(K,matrix[i][0],r,matrix[i][1],b,S);
            calldelta_5[i]=Batch_5_1.CallDelta();
            putdelta_5[i]=Batch_5_1.PutDelta();    }

        for (int i = 0; i < Tvecsize; ++i){
            cout<<"call delta: "<<endl;
            cout<<calldelta_5[i]<<endl;
        }
        for (int i = 0; i < Tvecsize; ++i){
            cout<<"put delta: "<<endl;
            cout<<putdelta_5[i]<<endl;}*/
            // a matrix showing all the call and put deltas of batch 5 in each row with different T and sig values
            /*vector<vector<double>> deltamatrix(Tvecsize);
            for (int i = 0; i < Tvecsize; ++i){
                EuropeanOption Batch51(K,matrix[i][0],r,matrix[i][1],b,S);
                deltamatrix[i][0]=Batch51.CallDelta();
                deltamatrix[i][1]=Batch51.PutDelta();
            }

            for (int i = 0; i < Tvecsize; ++i){
                cout<<"call delta in matrix: "<<endl;
                cout<<deltamatrix[i][0]<<endl;
            }
            for (int i = 0; i < Tvecsize; ++i){
                cout<<"put delta in matrix: "<<endl;
                cout<<deltamatrix[i][1]<<endl;}*/

                //2.d
                // Create a h vector.
    vector<double> h_vector = mesher(0.1, 1, 0.01); //h = [0.1,1]; step size - 0.01

    //initialize vectors which store deltas and gammas
    vector<double> calldelta_numerical(h_vector.size());
    vector<double> putdelta_numerical(h_vector.size());
    vector<double> callgamma_numerical(h_vector.size());
    vector<double> putgamma_numerical(h_vector.size());

    //Use divided differences for 2a.
    //reset parameters of option1__ back to initial level
    option1__.T = T;
    option1__.sig = sig;
    option1__.S = S;
    //cout << S << endl;
    //cout << "Current Price\t h-value\t Call delta\t Put delta\t Call gamma\t Put gamma " << endl;
    for (int i = 0; i < h_vector.size(); ++i) {
        //fill the vector by computing the delta and gamma using divided version function of DeltaDiff and GammaDiff
        calldelta_numerical[i] = option1__.DeltaDiff(S, h_vector[i]);
        callgamma_numerical[i] = option1__.DeltaDiff(S, h_vector[i]);
        option1__.toggle(); //it's a put now
        putdelta_numerical[i] = option1__.DeltaDiff(S, h_vector[i]);
        putgamma_numerical[i] = option1__.DeltaDiff(S, h_vector[i]);
        option1__.toggle(); //it's a call now
        //cout << Svector[i] << "\t" << h_vector[i] << "\t" << calldelta_numerical[i] << "\t" << putdelta_numerical[i] << "\t" << callgamma_numerical[i] << "\t" << putgamma_numerical[i] << endl;

    }
    //print out the elements in the stored vector
    for (int i = 0; i < calldelta_numerical.size(); ++i) {

        cout << "Current Price: " << S << " h-value: " << h_vector[i] << " Call Delta : " << calldelta_numerical[i] << " Put Delta : " << putdelta_numerical[i] << " Call Gamma: " << callgamma_numerical[i] << " Put Gamma: " << putgamma_numerical[i] << endl;
        //cout << Svector[i] << "\t" << h_vector[i] << "\t" << calldelta_numerical[i] << "\t" << putdelta_numerical[i] << "\t" << callgamma_numerical[i] << "\t" << putgamma_numerical[i] << endl;

    }

    /*for (int i = 0; i < h_vector.size(); ++i){
        cout<<"call delta: "<<endl;
        cout<<calldelta_numerical[i]<<endl;
        cout<<"put delta: "<<endl;
        cout<<putdelta_numerical[i]<<endl;
        cout<<"call gamma: "<<endl;
        cout<<callgamma_numerical[i]<<endl;
        cout<<"put gamma: "<<endl;
        cout<<putgamma_numerical[i]<<endl;
    }*/

    // Use divided differences for 2.b
    //try another method
    vector<double> vecCDelta1, vecPDelta1;
    for (int i = 0; i < Svector.size(); i++) {
        for (int j = 0; j < h_vector.size(); j++) {
            vecCDelta1.push_back(option1__.DeltaDiff(Svector[i], h_vector[j]));
            option1__.toggle(); //a put now
            vecPDelta1.push_back(option1__.DeltaDiff(Svector[i], h_vector[j]));
            option1__.toggle(); //a call now

            cout << "S = " << Svector[i] << ", h = " << h_vector[j] << ", Delta of Call = " << vecCDelta1[i + j] << ", Delta of Put = " << vecPDelta1[i + j] << endl;
        }
    }


    return 0;
}
