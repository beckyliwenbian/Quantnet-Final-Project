//include header files
#include "Option.h"
#include "OptionException.h"
#include <iostream>
using namespace std;

double Option::CallDelta() const { // Delta of call

    throw OptionFunctionException("CallDelta()");
}

double Option::PutDelta() const { // Delta of put

    throw OptionFunctionException("PutDelta()");
}

double Option::CallGamma() const { // Gamma of call

    throw OptionFunctionException("CallGamma()");
}

double Option::PutGamma() const { // Gamma of put

    throw OptionFunctionException("PutGamma()");
}

double Option::CallVega() const { // Vega of call

    throw OptionFunctionException("CallVega()");
}

double Option::PutVega() const { // Vega of put

    throw OptionFunctionException("PutVega()");
}

double Option::CallTheta() const { // Theta of call

    throw OptionFunctionException("CallTheta()");
}

double Option::PutTheta() const { // Theta of put

    throw OptionFunctionException("PutTheta()");
}

void Option::init() { // initialise all default values which is the option type

    optType = "Call";
}

void Option::copy(const Option& o2) { // copy all values

    optType = o2.optType;
}

Option::Option() { // Default constructor

    //call default constructor by using init function
    init();
}

Option::Option(const Option& option2) { // copy constructor

    copy(option2);
}

Option::Option(const string& optionType) { // Constructor with option type

    init();
    optType = optionType;
}

Option::~Option() { // Destructor
}

// Member operator overloading
Option& Option::operator = (const Option& option2) { // Assignment operator

    //prevent self-assignment
    if (this != &option2) {
        //copy from the input option
        copy(option2);
    }

    return *this;
}

// Functions that calculate option prices and sensitivities
double Option::Price() const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return CallPrice();
    }
    else {
        return PutPrice();
    }
}

double Option::Delta() const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return CallDelta();
    }
    else {
        return PutDelta();
    }
}

double Option::Gamma() const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return CallGamma();
    }
    else
    {
        return PutGamma();
    }
}

double Option::Vega() const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return CallVega();
    }
    else {
        return PutVega();
    }
}

double Option::Theta() const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return CallTheta();
    }
    else {
        return PutTheta();
    }
}

// Modifier functions
void Option::toggle() {// Change option type (Call/Put, Put/Call)

    /*
    if (optType == "Call")
        optType = "Put";
    else
        optType = "Call";*/

    optType = ((optType == "Call") ? "Put" : "Call");
}
