#pragma once
#ifndef A_OPTION_H
#define A_OPTION_H
#include <iostream>
using namespace std;

class Option { //this is the parent class for all types of all options!
private:
    virtual double CallPrice() const = 0; // Price of call
    virtual double PutPrice() const = 0; // Price of put
    virtual double CallDelta() const; // Delta of call
    virtual double PutDelta() const; // Delta of put
    virtual double CallGamma() const; // Gamma of call
    virtual double PutGamma() const; // Gamma of put
    virtual double CallVega() const; // Vega of call
    virtual double PutVega() const; // Vega of put
    virtual double CallTheta() const; // Theta of call
    virtual double PutTheta() const; // Theta of put

protected:
    virtual void init(); // initialise all default values
    virtual void copy(const Option& o2); // copy all values

public:
    string optType;	// Option name (call, put)

public:
    Option(); // Default constructor
    Option(const Option& option2); // copy constructor
    Option(const string& optionType); // Constructor with option type
    virtual ~Option(); // Destructor

    // Member operator overloading
    Option& operator = (const Option& option2);

    // Functions that calculate option price and sensitivities
    double Price() const;
    double Delta() const;
    double Gamma() const;
    double Vega() const;
    double Theta() const;

    // Modifier functions
    void toggle(); // Change option type
};

#endif //A_OPTION_H
