#pragma once
//
// Created by becky bian on 2022/9/9.
//

#ifndef A_OPTIONEXCEPTION_H
#define A_OPTIONEXCEPTION_H
#include <iostream>
#include <sstream>
using namespace std;

class OptionException {
public:
    // Constructor and destructor
    OptionException() { // Default constructor
    }

    virtual ~OptionException() { // Destructor
    }

    virtual string GetMessage() = 0;
};


class OptionFunctionException : public OptionException {
    //derived class of OptionException
private:
    string function_name;

public:
    // Constructors and destructor
    OptionFunctionException() : OptionException() { // Default constructor
    }

    OptionFunctionException(string functionName) : OptionException()
    { // Constructor accepting erroneous function name

        function_name = functionName;
    }

    virtual ~OptionFunctionException() { // Destructor
    }

    string GetMessage() {  //get the message related to the exception
        stringstream stream;

        stream << "The option does not have or implement the " << function_name;

        return stream.str();
    }
};
#endif //A_OPTIONEXCEPTION_H
