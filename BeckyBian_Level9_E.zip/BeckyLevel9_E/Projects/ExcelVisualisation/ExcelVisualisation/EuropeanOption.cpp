//
// Created by becky bian on 2022/9/9.
//
//include useful header files
#include "EuropeanOption.h"
#include <boost/math/distributions/normal.hpp>
#include <cmath>
#include <iostream>

using namespace boost::math;
using namespace std;

double EuropeanOption::CallPrice() const {
    // Price of call
    // call global functions
    return ::CallPrice(T, K, sig, r, S, b);
}

double EuropeanOption::PutPrice() const {
    // Price of put
    return ::PutPrice(T, K, sig, r, S, b);
}

double EuropeanOption::CallDelta() const {
    // Delta of call
    return ::CallDelta(T, K, sig, r, S, b);
}

double EuropeanOption::PutDelta() const {
    // Delta of put
    return ::PutDelta(T, K, sig, r, S, b);
}

double EuropeanOption::CallGamma() const {
    // Gamma of call
    return ::CallGamma(T, K, sig, r, S, b);
}

double EuropeanOption::PutGamma() const {
    // Gamma of put
    return ::PutGamma(T, K, sig, r, S, b);
}

double EuropeanOption::CallVega() const {
    // Vega of call
    return ::CallVega(T, K, sig, r, S, b);
}

double EuropeanOption::PutVega() const {
    // Vega of put
    return ::PutVega(T, K, sig, r, S, b);
}

double EuropeanOption::CallTheta() const {
    // Theta of call
    return ::CallTheta(T, K, sig, r, S, b);
}

double EuropeanOption::PutTheta() const {
    // Theta of put
    return ::PutTheta(T, K, sig, r, S, b);
}

/////////////////////////////////////////////////////////////////////////////////////

void EuropeanOption::init() {	// Initialise all default values

    //firstly initialize parent class
    Option::init();  // Call Option (this is the default type)

    // Default values
    r = 0.05;
    sig = 0.2;

    K = 110.0;
    T = 0.5;
    S = 100;

    b = r;			// Black and Scholes stock option model (1973)

    //optType = "Call";		// European Call Option (this is the default type)
}

void EuropeanOption::copy(const EuropeanOption& o2) {
    //copy from parent class first
    Option::copy(o2);

    r = o2.r;
    sig = o2.sig;
    K = o2.K;
    T = o2.T;
    b = o2.b;
    S = o2.S;


}

EuropeanOption::EuropeanOption() : Option() { // Default constructor which generates a call option
    init();
}


EuropeanOption::EuropeanOption(const EuropeanOption& option2) : Option(option2) { // Copy constructor
    copy(option2);
}

EuropeanOption::EuropeanOption(const string& optionType) : Option(optionType) {	// Constructor with Option Type
    init();
}

EuropeanOption::EuropeanOption(const struct EuropeanOptionData& optionData) : Option() { // Constructor with option data

    init();
    T = optionData.T;
    K = optionData.K;
    sig = optionData.sig;
    r = optionData.r;
    S = optionData.S;
    b = optionData.b;
}

EuropeanOption::~EuropeanOption() { //Destructor

}


EuropeanOption& EuropeanOption::operator = (const EuropeanOption& option2) { // Assignment operator

    Option::operator = (option2);
    //prevent self-assignment
    if (this == &option2) return *this;
    //copy from input option
    copy(option2);

    return *this;
}

double EuropeanOption::CallToPut(double c_price) const { // Use put-call parity to calculate put price

    return c_price + K * exp(-r * T) - S;
}

double EuropeanOption::PutToCall(double p_price) const { // Use put-call parity to calculate call price

    return p_price + S - K * exp(-r * T);
}

double EuropeanOption::PriceWithS(double new_S) const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return ::CallPrice(T, K, sig, r, new_S, b);
    }
    else {
        return ::PutPrice(T, K, sig, r, new_S, b);
    }
}

double EuropeanOption::PriceWithT(double new_T) const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return ::CallPrice(new_T, K, sig, r, S, b);
    }
    else {
        return ::PutPrice(new_T, K, sig, r, S, b);
    }
}

double EuropeanOption::PriceWithTsig(double new_T, double new_sig) const { //a function which computes the option price using new T and sig values
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return ::CallPrice(new_T, K, new_sig, r, S, b);
    }
    else {
        return ::PutPrice(new_T, K, new_sig, r, S, b);
    }
}

double EuropeanOption::PriceWithSig(double new_sig) const {
    //Determine what price function to use depending on the option type
    if (optType == "Call") {
        return ::CallPrice(T, K, new_sig, r, S, b);
    }
    else {
        return ::PutPrice(T, K, new_sig, r, S, b);
    }
}

//global functions
double EuropeanOption::DeltaDiff(double S, double h) const {
    // Use divided differences to calculate Delta
    return (PriceWithS(S + h) - PriceWithS(S - h)) / (2.0 * h);
}

double EuropeanOption::GammaDiff(double S, double h) const {
    // Use divided differences to calculate Gamma
    return (PriceWithS(S + h) - 2.0 * PriceWithS(S) + PriceWithS(S - h)) / (h * h);
}

double CallPrice(double T, double K, double sig, double r, double S, double b) {
    double tmp = sig * sqrt(T);
    double d1 = (log(S / K) + (b + (sig * sig) * 0.5) * T) / tmp;
    double d2 = d1 - tmp;
    normal_distribution<> normalDist(0, 1);

    return (S * exp((b - r) * T) * cdf(normalDist, d1)) - (K * exp(-r * T) * cdf(normalDist, d2));
}

double PutPrice(double T, double K, double sig, double r, double S, double b) {
    double tmp = sig * sqrt(T);
    double d1 = (log(S / K) + (b + (sig * sig) * 0.5) * T) / tmp;
    double d2 = d1 - tmp;
    normal_distribution<> normalDist(0, 1);

    return (K * exp(-r * T) * cdf(normalDist, -d2)) - (S * exp((b - r) * T) * cdf(normalDist, -d1));
}

double CallDelta(double T, double K, double sig, double r, double S, double b) {
    normal_distribution<> normalDist(0, 1);
    double tmp = sig * sqrt(T);
    double d1 = (log(S / K) + (b + (sig * sig) * 0.5) * T) / tmp;
    return exp((b - r) * T) * cdf(normalDist, d1);
}

double PutDelta(double T, double K, double sig, double r, double S, double b) {
    return CallDelta(T, K, sig, r, S, b) - exp((b - r) * T);
}

double CallGamma(double T, double K, double sig, double r, double S, double b) {
    normal_distribution<> normalDist(0, 1);
    double tmp = sig * sqrt(T);
    double d1 = (log(S / K) + (b + (sig * sig) * 0.5) * T) / tmp;
    return pdf(normalDist, d1) * exp((b - r) * T) / (S * sig * sqrt(T));
}

double PutGamma(double T, double K, double sig, double r, double S, double b) {
    return CallGamma(T, K, sig, r, S, b);
}

double CallVega(double T, double K, double sig, double r, double S, double b) {
    normal_distribution<> normalDist(0, 1);
    double tmp = sig * sqrt(T);
    double d1 = (log(S / K) + (b + (sig * sig) * 0.5) * T) / tmp;
    return S * sqrt(T) * exp((b - r) * T) * pdf(normalDist, d1);
}

double PutVega(double T, double K, double sig, double r, double S, double b) {
    return CallVega(T, K, sig, r, S, b);
}

double CallTheta(double T, double K, double sig, double r, double S, double b) {
    normal_distribution<> normalDist(0, 1);
    double tmp = sig * sqrt(T);
    double d1 = (log(S / K) + (b + (sig * sig) * 0.5) * T) / tmp;
    double d2 = d1 - tmp;
    return -S * sig * exp((b - r) * T) * pdf(normalDist, d1) / (2 * sqrt(T))
        - (b - r) * S * exp((b - r) * T) * cdf(normalDist, d1) - r * K * exp(-r * T) * cdf(normalDist, d2);
}

double PutTheta(double T, double K, double sig, double r, double S, double b) {
    return CallTheta(T, K, sig, r, S, b) + r * K * exp(-r * T) + S * exp((b - r) * T) * (b - r);
}

