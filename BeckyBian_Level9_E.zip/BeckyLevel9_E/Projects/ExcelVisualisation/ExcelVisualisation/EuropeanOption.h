#pragma once
//
// Created by becky bian on 2022/9/9.
//

#ifndef A_EUROPEANOPTION_H
#define A_EUROPEANOPTION_H
#include <string>
//include header files
#include "Option.h"
using namespace std;

//derived class from Option
class EuropeanOption : public Option {

private:

    void init();	// Initialise all default values
    void copy(const EuropeanOption& o2);

    double CallPrice() const; // Price of call
    double PutPrice() const;  // Price of put
    double CallDelta() const;  // Delta of call
    double PutDelta() const;   // Delta of put
    double CallGamma() const; // Gamma of call
    double PutGamma() const; // Gamma of put
    double CallVega() const; // Vega of call
    double PutVega() const; // Vega of put
    double CallTheta() const; // Theta of call
    double PutTheta() const; // Theta of put


    // Gaussian functions
    //double n(double x) const;
    //double N(double x) const;

public:

    // Member data public for convenience; anyway, the format will
    // not change for a plain option.

    double r;		// Interest rate
    double sig;		// Volatility
    double K;		// Strike price
    double T;		// Expiry date
    double b;		// Cost of carry
    double S; //asset price current

    //string optType;	// Option name (call, put)
    //string unam;	// Name of underlying asset


public:	// Public functions
    EuropeanOption();							// Default call option
    //	Overloaded constructor
    //EuropeanOption(double K_c, double T_c, double r_c, double sig_c, double b_c, double S_c, string str);
    // Overloaded constructor to create  OptionData sturct instance.
    //EuropeanOption(double K_c, double T_c, double r_c, double sig_c, double b_c, double S_c);

    EuropeanOption(const EuropeanOption& option2);	// Copy constructor
    EuropeanOption(const string& optionType);	// Constructor with option type
    EuropeanOption(const struct EuropeanOptionData& optionData); // Constructor with option data
    virtual ~EuropeanOption(); //destructor

    EuropeanOption& operator = (const EuropeanOption& option2); //assignment operator

    // Functions that calculate option price and sensitivities
    double CallToPut(double c_price) const; // Use put-call parity to calculate put price
    double PutToCall(double p_price) const; // Use put-call parity to calculate call price
    double PriceWithS(double new_S) const; // Use underlying price as argument
    double PriceWithT(double new_T) const; // Use expiry time as argument
    double PriceWithTsig(double new_T, double new_sig) const; // Use expiry time and volatility as arguments
    double PriceWithSig(double new_sig) const; // Use volatility as argument
    double DeltaDiff(double S, double h) const; // Use divided differences to calculate Delta
    double GammaDiff(double S, double h) const; // Use divided differences to calculate Gamma
    // functions to calculate delta and gamme using divided difference

    // Functions of put_call_parity
    //double CallToPut(double c_price, double asset_price) const; // Use put-call parity to calculate put price
    //double PutToCall(double p_price, double asset_price) const; // Use put-call parity to calculate call price

    // Modifier functions
    //void toggle();		// Change option type (C/P, P/C); it's in parent class
};

struct EuropeanOptionData {
    double r;		// Interest rate
    double sig;		// Volatility
    double K;		// Strike price
    double T;		// Expiry date
    double b;		// Cost of carry
    double S; //asset price current
};

// Global Functions
// used to work for all types of options globally
//vector<double> GenerateMeshArray(double min, double max, double h);
double CallPrice(double T, double K, double sig, double r, double S, double b);
double PutPrice(double T, double K, double sig, double r, double S, double b);
double CallDelta(double T, double K, double sig, double r, double S, double b);
double PutDelta(double T, double K, double sig, double r, double S, double b);
double CallGamma(double T, double K, double sig, double r, double S, double b);
double PutGamma(double T, double K, double sig, double r, double S, double b);
double CallVega(double T, double K, double sig, double r, double S, double b);
double PutVega(double T, double K, double sig, double r, double S, double b);
double CallTheta(double T, double K, double sig, double r, double S, double b);
double PutTheta(double T, double K, double sig, double r, double S, double b);
#endif //A_EUROPEANOPTION_H
