#pragma once
#include "Option.h"
#include "EuropeanOption.h"
#include "UtilitiesDJD/VectorsAndMatrices/Vector.cpp"
#include "UtilitiesDJD/Geometry/Range.cpp"
#include "UtilitiesDJD/ExceptionClasses/DatasimException.hpp"
#include "UtilitiesDJD/ExcelDriver/ExcelDriverLite.hpp"
#include "UtilitiesDJD/ExcelDriver/Utilities.hpp"
#include <cmath>
#include <list>
#include <string>
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>
#include <iostream> 
#include <vector>
#include <fstream>
using namespace std;

/*
Cost of carry factor b must be included in formulae depending on the
derivative type. These are used in the generalised Black-Scholes formula.
If r is the risk-free interest and q is the continuous dividend yield then
the cost-of-carry b per derivative type is:

a) Black-Scholes (1973) stock option model: b = r
b) b = r - q Merton (1973) stock option model with continuous dividend yield
c) b = 0 Black (1976) futures option model
d) b = r - rf Garman and Kohlhagen (1983) currency option model, where rf is the
'foreign' interest rate
*/

//global function
vector<double> mesher(double min, double max, double h) {
	int nelements = (max - min) / h + 1;

	vector<double> xarr(nelements);
	xarr[0] = min;
	xarr[xarr.size() - 1] = max;

	for (int n = 1; n < xarr.size() - 1; ++n) {
		xarr[n] = xarr[n - 1] + h;
	}

	return xarr;
}


int main(){
	//create vectors to store all the required info and batch info
	vector<double> Svector = mesher(10, 50, 1); // Vector of S values.
	int Svecsize = Svector.size();
	list<std::string> labels; // Names of each batch
	list<vector<double> > functionResult; // The list of price values

	//Method1 for preparing data
	/*
	//initialize the label names
	labels.push_back("Batch 1 Call");
	labels.push_back("Batch 1 Put");
	labels.push_back("Batch 2 Call");
	labels.push_back("Batch 2 Put");
	labels.push_back("Batch 3 Call");
	labels.push_back("Batch 3 Put");
	labels.push_back("Batch 4 Call");
	labels.push_back("Batch 4 Put");

	//Batch 1
	double T1 = 0.25;
	double K1 = 65;
	double sig1 = 0.30;
	double r1 = 0.08;
	double S1 = 60;
	double b1 = r1;
	
	//use an instance of EuropeanOption class to compute for price as a trial
	EuropeanOption option1;
	option1.T = T1;
	option1.K = K1;
	option1.sig = sig1;
	option1.r = r1;
	option1.S = S1;
	option1.b = b1;

	// calculate prices on a range of underlying prices
	// a vector showing all the call prices of batch 1 with different S values
	vector<double> call1(Svecsize);
	// a vector showing all the put prices of batch 1 with different S values
	vector<double> put1(Svecsize);
	//cout << "Current price\t Call Prices\t Put Prices" << endl;
	//cout << "Batch 1: compute for a range of underlying prices" << endl;
	for (int i = 0; i < Svecsize; ++i) {
		call1[i] = option1.PriceWithS(Svector[i]);
		option1.toggle(); //now, it's put again
		put1[i] = option1.PriceWithS(Svector[i]);
		option1.toggle(); //now, it's call again
	}
	//store batch 1 result
	functionResult.push_back(call1);
	functionResult.push_back(put1);

	//Batch 2
	double T2 = 1.0;
	double K2 = 100;
	double sig2 = 0.2;
	double r2 = 0.0;
	double S2 = 100;
	double b2 = r2;
	//use an instance of EuropeanOption class to compute for price as a trial
	EuropeanOption option2;
	option2.T = T2;
	option2.K = K2;
	option2.sig = sig2;
	option2.r = r2;
	option2.S = S2;
	option2.b = b2;

	//compute option prices using a range of underlying prices
	// a vector showing all the call prices of batch 2 with different S values
	vector<double> call2(Svecsize);
	// a vector showing all the put prices of batch 2 with different S values
	vector<double> put2(Svecsize);
	//cout<<"Current price\t Call Prices\t Put Prices"<<endl;
	//cout << "Batch 2: compute its price for a range of underlying prices" << endl;
	for (int i = 0; i < Svecsize; ++i) {
		call2[i] = option2.PriceWithS(Svector[i]);
		option2.toggle(); //now, it's put again
		put2[i] = option2.PriceWithS(Svector[i]);
		option2.toggle(); //now, it's call again

	}
	//store batch 2 result
	functionResult.push_back(call2);
	functionResult.push_back(put2);

	//Batch 3
	double T3 = 1.0;
	double K3 = 10;
	double sig3 = 0.50;
	double r3 = 0.12;
	double S3 = 5;
	double b3 = r3;
	//use an instance of EuropeanOption class to compute for price as a trial
	EuropeanOption option3;
	option3.T = T3;
	option3.K = K3;
	option3.sig = sig3;
	option3.r = r3;
	option3.S = S3;
	option3.b = b3;

	//compute option prices using a range of underlying prices
	// a vector showing all the call prices of batch 3 with different S values
	vector<double> call3(Svecsize);
	// a vector showing all the put prices of batch 3 with different S values
	vector<double> put3(Svecsize);
	//cout<<"Current price\t Call Prices\t Put Prices"<<endl;
	//cout << "Batch 3: compute its price for a range of underlying prices " << endl;
	for (int i = 0; i < Svecsize; ++i) {
		call3[i] = option3.PriceWithS(Svector[i]);
		option3.toggle(); //now, it's put again
		put3[i] = option3.PriceWithS(Svector[i]);
		option3.toggle(); //now, it's call again

	}
	//store batch 3 result
	functionResult.push_back(call3);
	functionResult.push_back(put3);

	//Batch 4
	double T4 = 30.0;
	double K4 = 100;
	double sig4 = 0.30;
	double r4 = 0.08;
	double S4 = 100;
	double b4 = r4;
	//use an instance of EuropeanOption class to compute for price as a trial
	EuropeanOption option4;
	option4.T = T4;
	option4.K = K4;
	option4.sig = sig4;
	option4.r = r4;
	option4.S = S4;
	option4.b = b4;

	// a vector showing all the call prices of batch 4 with different S values
	vector<double> call4(Svecsize);
	// a vector showing all the put prices of batch 4 with different S values
	vector<double> put4(Svecsize);
	//cout<<"Current price\t Call Prices\t Put Prices"<<endl;
	cout << "Batch 4: compute its price for a range of underlying prices" << endl;
	for (int i = 0; i < Svecsize; ++i) {
		call4[i] = option4.PriceWithS(Svector[i]);
		option4.toggle(); //now, it's put again
		put4[i] = option4.PriceWithS(Svector[i]);
		option4.toggle(); //now, it's call again
	}
	//store batch 4 result
	functionResult.push_back(call4);
	functionResult.push_back(put4);
	*/

	//Method 2 for data preparation
	// Store Batch 1 to Batch 4 data in a vector.
	typedef boost::tuple<double, double, double, double, double> tuplefive;
	vector<tuplefive> vecbatch;
	vecbatch.push_back(boost::make_tuple(0.25, 65.0, 0.30, 0.08, 60.0));
	vecbatch.push_back(boost::make_tuple(1.0, 100.0, 0.2, 0.0, 100.0));
	vecbatch.push_back(boost::make_tuple(1.0, 10.0, 0.50, 0.12, 5.0));
	vecbatch.push_back(boost::make_tuple(30.0, 100.0, 0.30, 0.08, 100.0));

	//declare variables to use in the loop
	double T, K, sig, r, S, b;
	stringstream ss;
	string str;

	for (int i = 0; i < vecbatch.size(); i++){
		// Add column name.
		ss << i + 1;
		ss >> str;
		labels.push_back("Batch " + str + " Call");
		labels.push_back("Batch " + str + " Put");
		ss.clear();

		T = vecbatch[i].get<0>();
		K = vecbatch[i].get<1>();
		sig = vecbatch[i].get<2>();
		r = vecbatch[i].get<3>();
		S = vecbatch[i].get<4>();
		b = r;

		// Use EuropeanOptionData.
		EuropeanOptionData optionData;
		optionData.T = T;
		optionData.K = K;
		optionData.sig = sig;
		optionData.r = r;
		optionData.S = S;
		optionData.b = b;
		EuropeanOption option(optionData);

		// Store option prices in vectors.
		vector<double> call(Svecsize), put(Svecsize);
		for (int j = 0; j < Svector.size(); j++){
			call[j] = option.PriceWithS(Svector[j]);
			option.toggle(); //it's a put now
			put[j] = option.PriceWithS(Svector[j]);
			option.toggle(); //it's a call now
		}

		//store the call and put prices of each batch
		functionResult.push_back(call);
		functionResult.push_back(put);
	}

	//tell the user that process ends
	cout << "Data has been created" << endl;

	// Print the results in Excel.
	try
	{
		ExcelDriver xl; xl.MakeVisible(true);
		xl.CreateChart(Svector, labels, functionResult, "Graph in One", "Underlying Value", "Option Price");
	}
	catch (DatasimException& e)
	{
		e.print();
	}
}